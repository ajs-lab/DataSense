# Databricks notebook source
# Lab 04 — Delta Tables Deep Dive
# ============================================================
# Prerequisites: Lab 02 complete (training_db.diamonds exists)
# ============================================================

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab 04 — Delta Tables Deep Dive
# MAGIC
# MAGIC **What you'll learn:**
# MAGIC - Delta history and time travel
# MAGIC - MERGE / UPSERT operations
# MAGIC - Schema evolution
# MAGIC - OPTIMIZE and VACUUM
# MAGIC - Delta constraints

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import col, current_timestamp, lit

DELTA_PATH = "/tmp/training/diamonds_delta"

# COMMAND ----------

# MAGIC %md ## 1. Delta Table History

# COMMAND ----------

# MAGIC %sql
# MAGIC -- View the transaction log / history of the table
# MAGIC DESCRIBE HISTORY training_db.diamonds

# COMMAND ----------

# MAGIC %md ## 2. Time Travel — Query Previous Versions

# COMMAND ----------

# Read version 0 (the first write)
df_v0 = (
    spark.read
    .format("delta")
    .option("versionAsOf", 0)
    .load(DELTA_PATH)
)
print(f"Version 0 row count: {df_v0.count():,}")

# COMMAND ----------

# You can also time travel by timestamp
# df_old = spark.read.format("delta").option("timestampAsOf", "2024-01-01").load(DELTA_PATH)

# COMMAND ----------

# MAGIC %md ## 3. MERGE / UPSERT

# COMMAND ----------

# Create a "updates" DataFrame — some existing rows changed, some are new
updates_data = [
    (1, "Ideal",   "E", "SI2",  62.5, 55, 350, 3.95, 3.98, 2.43),   # update: existing _c0=1
    (2, "Premium", "F", "SI1",  61.0, 58, 380, 4.05, 4.08, 2.48),   # update: existing _c0=2
    (99999, "Ideal", "D", "IF", 60.0, 57, 9999, 8.00, 8.00, 4.80),  # insert: new row
]
cols = ["_c0", "cut", "color", "clarity", "depth", "table", "price", "x", "y", "z"]
df_updates = spark.createDataFrame(updates_data, cols)
display(df_updates)

# COMMAND ----------

# Load the Delta table as a DeltaTable object
delta_table = DeltaTable.forPath(spark, DELTA_PATH)

# MERGE: update existing rows, insert new rows
(
    delta_table.alias("target")
    .merge(
        df_updates.alias("source"),
        condition="target._c0 = source._c0"
    )
    .whenMatchedUpdate(set={
        "price":   "source.price",
        "cut":     "source.cut",
    })
    .whenNotMatchedInsertAll()
    .execute()
)

print("✅ MERGE complete")

# COMMAND ----------

# Verify: check history now shows a new version
# MAGIC %sql
# MAGIC DESCRIBE HISTORY training_db.diamonds

# COMMAND ----------

# MAGIC %md ## 4. Schema Evolution

# COMMAND ----------

# Create a new DataFrame with an extra column
df_with_extra_col = spark.table("training_db.diamonds").withColumn("loaded_at", current_timestamp())

# Write with schema evolution enabled (mergeSchema)
(
    df_with_extra_col
    .write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .save(DELTA_PATH)
)

print("✅ Schema evolved — 'loaded_at' column added")

# COMMAND ----------

# Confirm new schema
spark.read.format("delta").load(DELTA_PATH).printSchema()

# COMMAND ----------

# MAGIC %md ## 5. OPTIMIZE — Compact Small Files

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Compact small Parquet files into larger ones (improves read performance)
# MAGIC OPTIMIZE training_db.diamonds

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Z-ORDER: co-locate related data by a column (great for columns used in WHERE filters)
# MAGIC OPTIMIZE training_db.diamonds ZORDER BY (cut, price)

# COMMAND ----------

# MAGIC %md ## 6. VACUUM — Remove Old Files

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Show current retention configuration (default is 7 days)
# MAGIC DESCRIBE DETAIL training_db.diamonds

# COMMAND ----------

# MAGIC %sql
# MAGIC -- VACUUM removes files older than the retention period
# MAGIC -- WARNING: after VACUUM you CANNOT time travel to removed versions
# MAGIC -- For training, we use RETAIN 0 HOURS (⚠️ don't do this in production!)
# MAGIC -- VACUUM training_db.diamonds RETAIN 168 HOURS  -- safe production usage (7 days)
# MAGIC SELECT "Run VACUUM only when you understand the retention implications" AS reminder

# COMMAND ----------

# MAGIC %md ## 7. Delta Constraints (Data Quality)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Add a CHECK constraint to enforce data quality rules
# MAGIC ALTER TABLE training_db.diamonds
# MAGIC ADD CONSTRAINT price_positive CHECK (price > 0);

# COMMAND ----------

# MAGIC %sql
# MAGIC -- View constraints on the table
# MAGIC DESCRIBE DETAIL training_db.diamonds

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Lab 04 Complete!
# MAGIC
# MAGIC You now know advanced Delta Table features:
# MAGIC - **History** — every write is versioned automatically
# MAGIC - **Time Travel** — query any previous version by version number or timestamp
# MAGIC - **MERGE** — efficient upserts with matched/not-matched conditions
# MAGIC - **Schema Evolution** — add columns without rewriting the table
# MAGIC - **OPTIMIZE + Z-ORDER** — compact files and co-locate data for faster queries
# MAGIC - **VACUUM** — clean up old files (respect the retention window!)
# MAGIC - **Constraints** — enforce data quality rules at the table level
# MAGIC
# MAGIC **Next → Lab 05: Workflows & Git Integration**
