# Databricks notebook source
# Lab 01 — Workspace, Clusters & Notebooks
# ============================================================
# Run each cell with Shift+Enter or click ▶ Run Cell
# Make sure you are attached to a running cluster first!
# ============================================================

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab 01 — Workspace, Clusters & Notebooks
# MAGIC
# MAGIC **What you'll learn:**
# MAGIC - Navigating the Databricks Workspace UI
# MAGIC - Running Python, SQL, and shell commands in the same notebook
# MAGIC - Using `dbutils` to explore the filesystem
# MAGIC - Basic display and output

# COMMAND ----------

# MAGIC %md ## 1. Check Your Spark Session
# MAGIC Every notebook on a running cluster has a live SparkSession available as `spark`.

# COMMAND ----------

# Print the Spark version — confirms your cluster is connected
print("Spark version:", spark.version)
print("Python version:", __import__("sys").version)

# COMMAND ----------

# MAGIC %md ## 2. Magic Commands
# MAGIC
# MAGIC Use `%` magic commands to switch languages per cell.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- This cell runs SQL even though the notebook default is Python
# MAGIC SELECT current_date() AS today, current_timestamp() AS now

# COMMAND ----------

# MAGIC %sh
# MAGIC # Shell commands — useful for installing packages or checking the environment
# MAGIC echo "Hostname: $(hostname)"
# MAGIC python3 --version

# COMMAND ----------

# MAGIC %md ## 3. Explore the Filesystem with dbutils
# MAGIC
# MAGIC `dbutils.fs` lets you navigate DBFS (Databricks File System) and cloud storage.

# COMMAND ----------

# List the root of DBFS
display(dbutils.fs.ls("/"))

# COMMAND ----------

# List the /databricks-datasets directory (free sample datasets provided by Databricks)
display(dbutils.fs.ls("/databricks-datasets/"))

# COMMAND ----------

# MAGIC %md ## 4. Widgets — Parameterized Notebooks
# MAGIC
# MAGIC Widgets let you pass parameters to a notebook from Jobs or other notebooks.

# COMMAND ----------

# Create a text widget
dbutils.widgets.text("environment", "dev", "Environment")
dbutils.widgets.dropdown("log_level", "INFO", ["DEBUG", "INFO", "WARN", "ERROR"], "Log Level")

# Read widget values
env = dbutils.widgets.get("environment")
log_level = dbutils.widgets.get("log_level")

print(f"Environment : {env}")
print(f"Log Level   : {log_level}")

# COMMAND ----------

# Clean up widgets when done
dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %md ## 5. Markdown Documentation
# MAGIC
# MAGIC Use `%md` cells to document your notebooks — supports standard Markdown.
# MAGIC
# MAGIC | Feature | Example |
# MAGIC |---------|---------|
# MAGIC | **Bold** | `**text**` |
# MAGIC | *Italic* | `*text*` |
# MAGIC | Code | `` `code` `` |
# MAGIC | Link | `[text](url)` |

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Lab 01 Complete!
# MAGIC
# MAGIC You now know how to:
# MAGIC - Access `spark` and check your cluster
# MAGIC - Use `%sql`, `%sh`, and `%md` magic commands
# MAGIC - Explore DBFS with `dbutils.fs`
# MAGIC - Create and read widgets
# MAGIC
# MAGIC **Next → Lab 02: Reading & Writing Data**
