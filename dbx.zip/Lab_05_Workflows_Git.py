# Databricks notebook source
# Lab 05 — Workflows & Git Integration
# ============================================================
# Prerequisites: Labs 01–04 complete
# ============================================================

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab 05 — Workflows & Git Integration
# MAGIC
# MAGIC **What you'll learn:**
# MAGIC - Designing notebooks for use as Job tasks
# MAGIC - Passing parameters with widgets
# MAGIC - Chaining notebooks with `%run` and `dbutils.notebook.run`
# MAGIC - Git best practices in Databricks Repos
# MAGIC - End-to-end mini-pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part A — Designing Notebooks as Job Tasks
# MAGIC
# MAGIC When a notebook runs as a **Workflow task**, parameters are passed via:
# MAGIC 1. **Widgets** (defined with `dbutils.widgets`)
# MAGIC 2. **Job parameters** (accessed via `dbutils.widgets.get`)
# MAGIC
# MAGIC The notebook should return a status so the Workflow knows it succeeded.

# COMMAND ----------

# MAGIC %md ### Step 1: Define Input Parameters

# COMMAND ----------

# Always define widgets at the top so they appear in the UI and Job config
dbutils.widgets.text("input_path",   "/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv", "Input Path")
dbutils.widgets.text("output_path",  "/tmp/training/pipeline_output", "Output Path")
dbutils.widgets.text("cut_filter",   "Ideal",      "Cut Filter")
dbutils.widgets.text("run_date",     "2024-01-01", "Run Date")

# Read parameters
INPUT_PATH  = dbutils.widgets.get("input_path")
OUTPUT_PATH = dbutils.widgets.get("output_path")
CUT_FILTER  = dbutils.widgets.get("cut_filter")
RUN_DATE    = dbutils.widgets.get("run_date")

print(f"Input  : {INPUT_PATH}")
print(f"Output : {OUTPUT_PATH}")
print(f"Filter : cut = {CUT_FILTER}")
print(f"Run    : {RUN_DATE}")

# COMMAND ----------

# MAGIC %md ### Step 2: The Pipeline Logic

# COMMAND ----------

from pyspark.sql.functions import col, current_timestamp, lit, to_date

# --- EXTRACT ---
df_raw = (
    spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .csv(INPUT_PATH)
)
print(f"Extracted {df_raw.count():,} rows")

# --- TRANSFORM ---
df_transformed = (
    df_raw
    .filter(col("cut") == CUT_FILTER)
    .withColumn("price_per_carat", (col("price") / col("carat")).cast("double"))
    .withColumn("pipeline_run_date", to_date(lit(RUN_DATE)))
    .withColumn("processed_at", current_timestamp())
    .select("cut", "color", "clarity", "carat", "price", "price_per_carat",
            "pipeline_run_date", "processed_at")
)
row_count = df_transformed.count()
print(f"Transformed {row_count:,} rows after filter (cut = {CUT_FILTER})")

# --- LOAD ---
(
    df_transformed
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(OUTPUT_PATH)
)
print(f"Loaded to: {OUTPUT_PATH}")

# COMMAND ----------

# MAGIC %md ### Step 3: Return a Value to the Workflow

# COMMAND ----------

# Use dbutils.notebook.exit to pass a result back to the calling Job or notebook
# This value appears in the Workflow run output
import json

result = {
    "status":    "success",
    "rows_written": row_count,
    "output_path": OUTPUT_PATH,
    "cut_filter": CUT_FILTER,
}
print("Exit value:", json.dumps(result))
dbutils.notebook.exit(json.dumps(result))

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC ## Part B — Chaining Notebooks

# COMMAND ----------

# MAGIC %md
# MAGIC ### Option 1: %run (inline execution — shares SparkSession and variables)
# MAGIC
# MAGIC ```python
# MAGIC # %run "./Lab_03_PySpark_Essentials"
# MAGIC # After %run, all variables and DataFrames from that notebook are available here
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ### Option 2: dbutils.notebook.run (subprocess — isolated, returns a string)
# MAGIC
# MAGIC ```python
# MAGIC result_json = dbutils.notebook.run(
# MAGIC     path       = "./Lab_05_Workflows_Git",      # relative or absolute notebook path
# MAGIC     timeout_seconds = 300,
# MAGIC     arguments  = {
# MAGIC         "cut_filter":  "Premium",
# MAGIC         "output_path": "/tmp/training/premium_output",
# MAGIC         "run_date":    "2024-02-01",
# MAGIC     }
# MAGIC )
# MAGIC import json
# MAGIC result = json.loads(result_json)
# MAGIC print("Child notebook returned:", result)
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC ## Part C — Git Integration Guide
# MAGIC
# MAGIC ### Connecting a Repo
# MAGIC 1. Go to **Repos** in the left sidebar
# MAGIC 2. Click **Add Repo**
# MAGIC 3. Paste your GitHub / GitLab / Azure DevOps URL
# MAGIC 4. Authenticate with a Personal Access Token (PAT)
# MAGIC
# MAGIC ### Branch Workflow (from the Databricks UI)
# MAGIC ```
# MAGIC Repos → [Your Repo] → Branch dropdown → Create branch: feature/my-feature
# MAGIC   ↓
# MAGIC Edit notebooks in your feature branch
# MAGIC   ↓
# MAGIC Repos → [Your Repo] → Git dialog → Stage → Commit → Push
# MAGIC   ↓
# MAGIC Open PR in GitHub / GitLab → Code review → Merge to main
# MAGIC ```
# MAGIC
# MAGIC ### Best Practices
# MAGIC | ✅ Do | ❌ Don't |
# MAGIC |-------|---------|
# MAGIC | Work in feature branches | Commit directly to main |
# MAGIC | Commit often with clear messages | Leave uncommitted changes overnight |
# MAGIC | Use `.gitignore` for output files | Store secrets in notebooks |
# MAGIC | Pull before starting work | Ignore merge conflicts |

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC ## Part D — Creating a Workflow (Jobs) — Reference
# MAGIC
# MAGIC ### Via the UI:
# MAGIC 1. **Workflows** → **Create Job**
# MAGIC 2. Name your job (e.g., `diamonds-pipeline-daily`)
# MAGIC 3. **Add Task**:
# MAGIC    - Type: **Notebook**
# MAGIC    - Notebook path: `/Repos/your-repo/Lab_05_Workflows_Git`
# MAGIC    - Cluster: **New Job Cluster** (choose DBR version)
# MAGIC    - Parameters: `{"cut_filter": "Ideal", "run_date": "{{job.start_time.iso_date}}"}`
# MAGIC 4. **Add trigger**: Schedule (cron) or manual
# MAGIC 5. Click **Run Now** to test
# MAGIC
# MAGIC ### Via REST API:
# MAGIC ```python
# MAGIC import requests, json
# MAGIC
# MAGIC DATABRICKS_HOST  = "https://<your-workspace>.azuredatabricks.net"
# MAGIC DATABRICKS_TOKEN = dbutils.secrets.get("scope", "api-token")
# MAGIC
# MAGIC response = requests.post(
# MAGIC     f"{DATABRICKS_HOST}/api/2.1/jobs/run-now",
# MAGIC     headers={"Authorization": f"Bearer {DATABRICKS_TOKEN}"},
# MAGIC     json={
# MAGIC         "job_id": 12345,
# MAGIC         "notebook_params": {"cut_filter": "Premium", "run_date": "2024-03-01"}
# MAGIC     }
# MAGIC )
# MAGIC print(response.json())
# MAGIC ```

# COMMAND ----------

# Clean up widgets
dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Lab 05 Complete — Training Done! 🎉
# MAGIC
# MAGIC ### You have now covered all 7 developer essentials:
# MAGIC
# MAGIC | # | Topic | Lab |
# MAGIC |---|-------|-----|
# MAGIC | 1 | Workspace & Cluster Setup | Lab 01 |
# MAGIC | 2 | Notebooks & Languages | Lab 01 |
# MAGIC | 3 | Reading & Writing Data | Lab 02 |
# MAGIC | 4 | PySpark Essentials | Lab 03 |
# MAGIC | 5 | Delta Tables | Lab 04 |
# MAGIC | 6 | Databricks Workflows | Lab 05 |
# MAGIC | 7 | Git Integration | Lab 05 |
# MAGIC
# MAGIC ### Recommended Next Steps:
# MAGIC - 📚 **Databricks Academy** — free courses at academy.databricks.com
# MAGIC - 🏅 **Databricks Certified Associate Developer for Apache Spark** — your first certification
# MAGIC - 🔬 **Delta Live Tables** — declarative ETL pipelines
# MAGIC - 🤖 **MLflow** — experiment tracking for ML projects
