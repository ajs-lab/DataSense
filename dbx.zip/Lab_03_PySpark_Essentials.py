# Databricks notebook source
# Lab 03 — PySpark Essentials
# ============================================================
# Prerequisites: Lab 02 complete (training_db.diamonds exists)
# ============================================================

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab 03 — PySpark Essentials
# MAGIC
# MAGIC **What you'll learn:**
# MAGIC - select, withColumn, alias
# MAGIC - filter / where
# MAGIC - groupBy / agg
# MAGIC - join
# MAGIC - sort / orderBy
# MAGIC - Union and deduplication

# COMMAND ----------

from pyspark.sql.functions import (
    col, lit, when, round as _round,
    count, avg, sum as _sum, max as _max, min as _min,
    upper, lower, concat, length, to_date, year, month,
    dense_rank, row_number
)
from pyspark.sql.window import Window

# Load our sample data
df = spark.table("training_db.diamonds")
display(df.limit(5))

# COMMAND ----------

# MAGIC %md ## 1. select & withColumn

# COMMAND ----------

# Select specific columns
df_select = df.select("cut", "color", "clarity", "price")
display(df_select.limit(5))

# COMMAND ----------

# Add a new column: price per carat
df_enriched = (
    df
    .withColumn("price_per_carat", _round(col("price") / col("carat"), 2))
    .withColumn("price_category",
        when(col("price") < 1000, "Budget")
        .when(col("price") < 5000, "Mid-Range")
        .otherwise("Premium")
    )
    .select("cut", "color", "carat", "price", "price_per_carat", "price_category")
)
display(df_enriched.limit(10))

# COMMAND ----------

# MAGIC %md ## 2. filter / where

# COMMAND ----------

# Filter: only Ideal cut diamonds over $5,000
df_ideal = df.filter((col("cut") == "Ideal") & (col("price") > 5000))
print(f"Ideal cut diamonds over $5k: {df_ideal.count():,}")
display(df_ideal.limit(5))

# COMMAND ----------

# SQL-style string filter also works
df_premium = df.where("cut IN ('Ideal', 'Premium') AND carat >= 1.5")
print(f"Premium/Ideal diamonds ≥ 1.5 carat: {df_premium.count():,}")

# COMMAND ----------

# MAGIC %md ## 3. groupBy & agg

# COMMAND ----------

# Average price and count per cut quality
df_by_cut = (
    df.groupBy("cut")
    .agg(
        count("*").alias("count"),
        _round(avg("price"), 2).alias("avg_price"),
        _round(avg("carat"), 3).alias("avg_carat"),
        _max("price").alias("max_price")
    )
    .orderBy("avg_price", ascending=False)
)
display(df_by_cut)

# COMMAND ----------

# Multi-level groupBy
df_cut_color = (
    df.groupBy("cut", "color")
    .agg(count("*").alias("count"), _round(avg("price"), 2).alias("avg_price"))
    .orderBy("cut", "avg_price", ascending=[True, False])
)
display(df_cut_color.limit(20))

# COMMAND ----------

# MAGIC %md ## 4. join

# COMMAND ----------

# Create a small reference DataFrame to join (cut quality ratings)
cut_ratings = spark.createDataFrame([
    ("Fair",      1, "Low quality - visible imperfections"),
    ("Good",      2, "Moderate quality"),
    ("Very Good", 3, "High quality"),
    ("Premium",   4, "Near-ideal proportions"),
    ("Ideal",     5, "Perfect proportions"),
], ["cut", "rating", "description"])

display(cut_ratings)

# COMMAND ----------

# Left join diamonds with cut ratings
df_joined = (
    df
    .join(cut_ratings, on="cut", how="left")
    .select("cut", "rating", "description", "carat", "price")
)
display(df_joined.limit(10))

# COMMAND ----------

# MAGIC %md ## 5. sort / orderBy

# COMMAND ----------

# Top 10 most expensive diamonds
df_top10 = (
    df.select("cut", "color", "clarity", "carat", "price")
    .orderBy(col("price").desc())
    .limit(10)
)
display(df_top10)

# COMMAND ----------

# MAGIC %md ## 6. Window Functions

# COMMAND ----------

# Rank diamonds by price within each cut category
window_spec = Window.partitionBy("cut").orderBy(col("price").desc())

df_ranked = (
    df
    .withColumn("rank_in_cut", dense_rank().over(window_spec))
    .filter(col("rank_in_cut") <= 3)   # Top 3 per cut
    .select("cut", "rank_in_cut", "carat", "color", "price")
    .orderBy("cut", "rank_in_cut")
)
display(df_ranked)

# COMMAND ----------

# MAGIC %md ## 7. Caching (Performance Tip)

# COMMAND ----------

# Cache a DataFrame you'll use repeatedly
df_ideal_cached = df.filter(col("cut") == "Ideal").cache()
df_ideal_cached.count()  # triggers the cache

# Now subsequent operations on df_ideal_cached are much faster
print("Cached Ideal diamonds:", df_ideal_cached.count())

# Always unpersist when done to free memory
df_ideal_cached.unpersist()
print("Cache cleared.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Lab 03 Complete!
# MAGIC
# MAGIC You can now use the core PySpark operations:
# MAGIC - `select`, `withColumn`, `when/otherwise`
# MAGIC - `filter` / `where` with column expressions and SQL strings
# MAGIC - `groupBy` + `agg` with multiple aggregate functions
# MAGIC - `join` (inner, left, right, outer)
# MAGIC - `orderBy` / `sort`
# MAGIC - Window functions with `Window.partitionBy`
# MAGIC - DataFrame caching
# MAGIC
# MAGIC **Next → Lab 04: Delta Tables Deep Dive**
