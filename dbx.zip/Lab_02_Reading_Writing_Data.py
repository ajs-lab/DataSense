# Databricks notebook source
# Lab 02 — Reading & Writing Data
# ============================================================
# Prerequisites: Lab 01 complete, cluster attached
# ============================================================

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab 02 — Reading & Writing Data
# MAGIC
# MAGIC **What you'll learn:**
# MAGIC - Reading CSV, JSON, and Parquet files
# MAGIC - Exploring DataFrames (schema, shape, sample rows)
# MAGIC - Writing data in Delta format
# MAGIC - Reading Delta Tables

# COMMAND ----------

# MAGIC %md ## 1. Read a CSV from Databricks Sample Datasets

# COMMAND ----------

# Read the diamonds dataset (a classic sample dataset built into Databricks)
df_diamonds = (
    spark.read
    .option("header", "true")
    .option("inferSchema", "true")
    .csv("/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv")
)

# Print the schema
df_diamonds.printSchema()

# COMMAND ----------

# Show the first 10 rows in a nice table
display(df_diamonds.limit(10))

# COMMAND ----------

# Check the row count and column count
print(f"Rows   : {df_diamonds.count():,}")
print(f"Columns: {len(df_diamonds.columns)}")

# COMMAND ----------

# MAGIC %md ## 2. Basic DataFrame Exploration

# COMMAND ----------

# Summary statistics for numeric columns
display(df_diamonds.describe())

# COMMAND ----------

# Check for nulls in each column
from pyspark.sql.functions import col, sum as _sum, count

null_counts = df_diamonds.select(
    [_sum(col(c).isNull().cast("int")).alias(c) for c in df_diamonds.columns]
)
display(null_counts)

# COMMAND ----------

# MAGIC %md ## 3. Read JSON Data

# COMMAND ----------

# Read the flights JSON dataset
df_flights = (
    spark.read
    .option("multiline", "true")
    .json("/databricks-datasets/flights/departuredelays.csv")
)

# Note: Spark infers JSON schemas automatically
display(df_flights.limit(5))

# COMMAND ----------

# MAGIC %md ## 4. Write Data as Delta Table

# COMMAND ----------

# Define a path in DBFS for our Delta table
DELTA_PATH = "/tmp/training/diamonds_delta"

# Write the diamonds dataframe as Delta format
(
    df_diamonds.write
    .format("delta")
    .mode("overwrite")   # Options: overwrite, append, ignore, error
    .save(DELTA_PATH)
)

print(f"✅ Delta table written to: {DELTA_PATH}")

# COMMAND ----------

# MAGIC %md ## 5. Read Back the Delta Table

# COMMAND ----------

# Read Delta table from path
df_from_delta = spark.read.format("delta").load(DELTA_PATH)

display(df_from_delta.limit(5))
print(f"Rows read from Delta: {df_from_delta.count():,}")

# COMMAND ----------

# MAGIC %md ## 6. Register as a SQL Table (optional but useful)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create a database for our training exercises
# MAGIC CREATE DATABASE IF NOT EXISTS training_db;

# COMMAND ----------

# Register the Delta table so you can query it with SQL
spark.sql("DROP TABLE IF EXISTS training_db.diamonds")
spark.sql(f"""
    CREATE TABLE training_db.diamonds
    USING DELTA
    LOCATION '{DELTA_PATH}'
""")
print("✅ Table registered: training_db.diamonds")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query the registered table using SQL
# MAGIC SELECT cut, COUNT(*) as count, ROUND(AVG(price), 2) as avg_price
# MAGIC FROM training_db.diamonds
# MAGIC GROUP BY cut
# MAGIC ORDER BY avg_price DESC

# COMMAND ----------

# MAGIC %md
# MAGIC ## ✅ Lab 02 Complete!
# MAGIC
# MAGIC You now know how to:
# MAGIC - Read CSV, JSON, and Parquet files with `spark.read`
# MAGIC - Explore DataFrames: schema, count, describe, null checks
# MAGIC - Write data in **Delta format** with `.write.format("delta")`
# MAGIC - Register a Delta table for SQL access
# MAGIC
# MAGIC **Next → Lab 03: PySpark Essentials**
